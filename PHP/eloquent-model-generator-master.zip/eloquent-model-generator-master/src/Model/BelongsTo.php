<?php

namespace Krlove\EloquentModelGenerator\Model;

/**
 * Class BelongsTo
 * @package Krlove\EloquentModelGenerator\Model
 */
class BelongsTo extends Relation
{
}
